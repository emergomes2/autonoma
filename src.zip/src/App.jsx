export default function App() {
  return <h1>Autônoma está no ar!</h1>
}
